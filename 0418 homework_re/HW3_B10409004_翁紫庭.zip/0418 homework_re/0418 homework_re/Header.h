#pragma once
int Fibonacci_1(int num);
int Fibonacci_2(int num);